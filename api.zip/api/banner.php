<?php
include 'db.php';

header("Content-Type: application/json");

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = $_GET['id'];
            $result = $conn->query("SELECT * FROM banner WHERE id=$id");
            $data = $result->fetch_assoc();
            echo json_encode($data);
        } else {
            $result = $conn->query("SELECT * FROM banner");
            $users = [];
            while ($row = $result->fetch_assoc()) {
                $users[] = $row;
            }
            echo json_encode($users);
        }
        break;

    case 'POST':

        if(isset($input['url']) && isset($input['image_url'])) {

            
        $url = $input['url'];
        $image_url = $input['image_url'];
        $link = $input['link'];
        $alt_text = $input['alt_text'];

        $width = $input['width'];
        $height = $input['height'];
        $position = $input['position'];
        
        $conn->query("INSERT INTO banner (url,image_url,link,alt_text,width,height,position) VALUES ('$url','$image_url','$link','$alt_text',$width,$height,$position)");
        echo json_encode(["message" => "Banner added successfully"]);
        break;
        } else {

            // print_r($_POST);

            if (isset($_POST['id'])) {
                $id = $_POST['id'];
                $result = $conn->query("SELECT * FROM banner WHERE id=$id");
                $data = $result->fetch_assoc();
                echo json_encode($data);
            } else {
                $result = $conn->query("SELECT * FROM banner");
                $users = [];
                while ($row = $result->fetch_assoc()) {
                    $users[] = $row;
                }
                echo json_encode($users);
            }
            break;

        }

    case 'PUT':
        $id = $input['id'];
        $url = $input['url'];
        $image_url = $input['image_url'];
        $link = $input['link'];
        $alt_text = $input['alt_text'];

        $width = $input['width'];
        $height = $input['height'];
        $position = $input['position'];
        $conn->query("UPDATE banner SET url='$url',
                     image_url='$image_url', link='$link',alt_text='$alt_text',width='$width',height='$height',position='$position' WHERE id=$id");
        echo json_encode(["message" => "Bannet updated successfully"]);
        break;

    case 'DELETE':
        $id = $_GET['id'];
        $conn->query("DELETE FROM banner WHERE id=$id");
        echo json_encode(["message" => "Banner deleted successfully"]);
        break;

    default:
        echo json_encode(["message" => "Invalid request method"]);
        break;
}

$conn->close();
?>
