

const params = {id: document.getElementById('banner_id').value,height:'',width:"",position:''}


var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
     
      const obj = JSON.parse(this.responseText);
      var length = obj.length
      var img = '';
      if(length > 1){

      for (let i = 0; i < length; i++) {
         img += '<a href="'+obj[i].link+'"><img src="'+obj[i].image_url + '"</></a><br>'
      }
        
        
      } else {
       img = '<a href="'+obj.link+'"><img src="'+obj.image_url + '"</></a><br>'
      }
   
    document.getElementById("banner").innerHTML = img
    
    }
  };
  xhttp.open("POST", "http://localhost/api/banner.php", true);
  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

  // will bring all images
  // xhttp.send();
  xhttp.send("id="+document.getElementById('banner_id').value);
 // xhttp.send(JSON.stringify(params)) 

